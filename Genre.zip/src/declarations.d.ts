declare module 'swiper/css/free-mode';
declare module 'swiper/css/navigation';
declare module 'swiper/css';