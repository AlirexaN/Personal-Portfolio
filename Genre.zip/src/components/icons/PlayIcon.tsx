// src/components/icons/PlayIcon.tsx
const PlayIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M16.9611 13.7365L8.99228 18.2901C7.65896 19.052 6 18.0893 6 16.5536V12V7.44636C6 5.91071 7.65896 4.94798 8.99228 5.70987L16.9611 10.2635C18.3048 11.0313 18.3048 12.9687 16.9611 13.7365Z"
        fill="#28303F"
      />
    </svg>
  );
};

export default PlayIcon; // استفاده از export default