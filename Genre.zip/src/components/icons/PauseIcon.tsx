// src/components/icons/PauseIcon.tsx
const PauseIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M6 5C4.89543 5 4 5.89543 4 7V17C4 18.1046 4.89543 19 6 19H8C9.10457 19 10 18.1046 10 17V7C10 5.89543 9.10457 5 8 5H6ZM16 5C14.8954 5 14 5.89543 14 7V17C14 18.1046 14.8954 19 16 19H18C19.1046 19 20 18.1046 20 17V7C20 5.89543 19.1046 5 18 5H16Z"
        fill="#28303F"
      />
    </svg>
  );
};

export default PauseIcon; // استفاده از export default